#!/usr/bin/env python3
"""Convert files to Markdown using MarkItDown.

Usage:
    python convert.py INPUT [INPUT ...] [-o OUTPUT] [--separate]

INPUT can be files, directories (recursed), or ZIP archives (contents
iterated). By default all results are combined into one Markdown file,
with a "# filename" header separating each source document. Pass
--separate to write one .md file per input instead.

Exit code 0 if at least one file converted; per-file errors are reported
but do not abort the batch.
"""
import argparse
import sys
import zipfile
import tempfile
from pathlib import Path

SKIP_SUFFIXES = {".md", ".markdown"}  # already markdown — copied through


def demote_headings(text):
    """Shift every Markdown heading down one level (# -> ##, etc.).

    Used in combined mode so the top-level '# filename' separators stay
    unambiguous — content headings can't collide with document boundaries.
    Lines inside fenced code blocks are left untouched.
    """
    out, in_fence = [], False
    for line in text.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            in_fence = not in_fence
        if not in_fence and line.startswith("#"):
            line = "#" + line
        out.append(line)
    return "\n".join(out)


def fix_empty_table_headers(text):
    """Repair tables whose header row is empty (a MarkItDown .docx quirk).

    Pattern produced: '|  |  |' header, '| --- |' divider, then the real
    header as the first data row. Promote that first data row to header.
    """
    lines = text.splitlines()
    i = 0
    while i + 2 < len(lines):
        hdr, div, first = lines[i], lines[i + 1], lines[i + 2]
        if (hdr.strip().startswith("|") and not hdr.replace("|", "").strip()
                and set(div.replace("|", "").strip()) <= set("- ")
                and first.strip().startswith("|") and first.replace("|", "").strip()):
            lines[i] = first
            del lines[i + 2]
        i += 1
    return "\n".join(lines)


def gather_files(inputs):
    """Expand dirs and zips into a flat list of (path, display_name)."""
    files = []
    for raw in inputs:
        p = Path(raw)
        if not p.exists():
            print(f"[skip] not found: {p}", file=sys.stderr)
            continue
        if p.is_dir():
            for child in sorted(p.rglob("*")):
                if child.is_file() and not child.name.startswith("."):
                    files.append((child, str(child.relative_to(p))))
        elif p.suffix.lower() == ".zip":
            tmp = Path(tempfile.mkdtemp(prefix="mid_zip_"))
            with zipfile.ZipFile(p) as zf:
                zf.extractall(tmp)
            for child in sorted(tmp.rglob("*")):
                if child.is_file() and not child.name.startswith("."):
                    files.append((child, f"{p.name}/{child.relative_to(tmp)}"))
        else:
            files.append((p, p.name))
    return files


def convert_all(files):
    from markitdown import MarkItDown

    md = MarkItDown()
    results, errors = [], []
    for path, display in files:
        if path.suffix.lower() in SKIP_SUFFIXES:
            results.append((display, path.read_text(errors="replace")))
            continue
        try:
            res = md.convert(str(path))
            text = fix_empty_table_headers((res.text_content or "").strip())
            if text:
                results.append((display, text))
            else:
                errors.append((display, "converted but produced no text"))
        except Exception as e:  # keep going on per-file failure
            errors.append((display, f"{type(e).__name__}: {e}"))
    return results, errors


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("inputs", nargs="+", help="files, directories, or zip archives")
    ap.add_argument("-o", "--output", default="converted.md",
                    help="combined output file, or output directory with --separate")
    ap.add_argument("--separate", action="store_true",
                    help="write one .md per input file instead of combining")
    args = ap.parse_args()

    files = gather_files(args.inputs)
    if not files:
        print("No input files found.", file=sys.stderr)
        sys.exit(1)

    results, errors = convert_all(files)

    if args.separate:
        outdir = Path(args.output)
        outdir.mkdir(parents=True, exist_ok=True)
        for display, text in results:
            out = outdir / (Path(display).stem + ".md")
            out.write_text(text + "\n")
            print(f"[ok] {display} -> {out}")
    else:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        parts = []
        for display, text in results:
            parts.append(f"# {display}\n\n{demote_headings(text)}\n")
        out.write_text("\n---\n\n".join(parts))
        print(f"[ok] wrote {len(results)} document(s) -> {out}")

    for display, err in errors:
        print(f"[error] {display}: {err}", file=sys.stderr)

    sys.exit(0 if results else 1)


if __name__ == "__main__":
    main()
