---
name: markitdown-converter
description: Convert files of almost any format (PDF, Word, PowerPoint, Excel, HTML, CSV, JSON, XML, images, audio, EPub, ZIP archives) into clean, structure-preserving Markdown using Microsoft's MarkItDown library — then optionally analyze or summarize the converted content. Use this skill whenever the user wants to convert documents to Markdown, extract text from mixed file types, prepare documents for an LLM pipeline or text analysis, turn a folder or ZIP of assorted files into one readable text file, or asks to "markdownify" anything. Also use it when the user uploads files in formats you can't read natively and wants their contents as text or Markdown.
---

# MarkItDown Converter

Convert files to Markdown that preserves document structure (headings, lists, tables, links), using Microsoft's [MarkItDown](https://github.com/microsoft/markitdown) library. The output is optimized for LLM consumption and text analysis pipelines — token-efficient and structurally faithful — not for pixel-perfect human-facing documents.

## Setup

```bash
pip install --break-system-packages -q 'markitdown[all]'
```

Install once per session before converting. The `[all]` extra pulls in converters for PDF, Office formats, images, audio, and EPub.

## Two modes — read the user's intent

The user usually wants one of two things:

1. **Convert and deliver**: they want the `.md` file itself. Convert, save the output where the user can access it (in Claude.ai: `/mnt/user-data/outputs/`), and share it.
2. **Convert as a means to an end**: they want analysis, a summary, a comparison, data extraction, etc. Convert to Markdown first (to a working directory like `/home/claude/`), then read the Markdown and do the actual task. Only share the `.md` file if it's genuinely useful to them — don't clutter the answer with an intermediate artifact they didn't ask for.

If the request is ambiguous ("here's a zip of reports, deal with this"), a combined Markdown file plus a brief summary of what's inside is a good default.

## How to convert

Use the bundled script — it handles single files, multiple files, directories (recursive), and ZIP archives, and it keeps going if one file in a batch fails:

```bash
python scripts/convert.py INPUT [INPUT ...] -o OUTPUT
```

Examples:

```bash
# Single file
python scripts/convert.py report.pdf -o /mnt/user-data/outputs/report.md

# A whole ZIP or folder -> ONE combined .md (default behavior)
python scripts/convert.py archive.zip -o /mnt/user-data/outputs/combined.md
python scripts/convert.py ./docs/ -o combined.md

# One .md per input file instead
python scripts/convert.py a.docx b.xlsx --separate -o ./out_dir/
```

**Batch default: combine.** When given multiple files, a directory, or a ZIP, produce one combined Markdown file. Each source document gets a top-level `# filename` header and documents are separated by `---` rules, so provenance stays clear. Use `--separate` only when the user asks for individual files.

For one-off programmatic use (e.g., converting in-memory as part of a larger script), the Python API is simple:

```python
from markitdown import MarkItDown
result = MarkItDown().convert("file.pdf")
text = result.text_content
```

## What converts well, and known limits

- **Strong**: PDF, Word (.docx), PowerPoint (.pptx), Excel (.xlsx/.xls), HTML, CSV/JSON/XML, EPub, ZIP. Tables come out as Markdown tables; headings and lists are preserved.
- **Images**: EXIF metadata extracts; OCR/captioning depends on optional dependencies and may yield little or nothing in a sandboxed environment. If an image converts to empty text and you can see the image natively in context, transcribe it yourself instead.
- **Audio**: transcription calls an external speech API and **will fail without open network access**. Tell the user this honestly rather than retrying.
- **YouTube URLs**: requires fetching from youtube.com — works only where that network access exists. In restricted environments, explain the limitation.
- **Legacy binary formats** (.doc, .ppt): unreliable. Suggest the user re-save as the modern format if conversion fails.

When a file in a batch fails, the script reports it on stderr and converts the rest. Always tell the user which files (if any) failed and why — silently dropping a document from a combined output is worse than an error message.

## Quality check before delivering

Skim the converted Markdown before handing it over. Two common issues worth a quick fix:

- Scanned/image-only PDFs convert to empty or near-empty text. Flag this to the user — don't deliver a blank file as if it succeeded.
- Spreadsheets with many sheets produce one table per sheet under `## SheetName` headers; confirm the sheet the user cares about is present.
