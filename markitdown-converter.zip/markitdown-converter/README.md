## markitdown-converter

### What it does

Wraps Microsoft's [MarkItDown](https://github.com/microsoft/markitdown) library so Claude can:

- **Convert and deliver** — turn a document into a `.md` file you can download.
- **Convert and analyze** — quietly convert a file to Markdown as an intermediate step, then answer questions about its contents (e.g. *"which product grew the most in this xlsx?"*).
- **Handle batches** — given a folder or ZIP of mixed files, produce **one combined Markdown file**, with a `# filename` header per source document and content headings demoted one level so document boundaries never collide with content. Pass `--separate` for one `.md` per file.

### Why Markdown?

Markdown is close to plain text but still encodes document structure (headings, lists, tables, links). LLMs understand it natively, and it's highly token-efficient — ideal for feeding documents into analysis pipelines.

### Supported input formats

PDF, Word (.docx), PowerPoint (.pptx), Excel (.xlsx/.xls), HTML, CSV, JSON, XML, EPub, ZIP archives, images (EXIF metadata; OCR where dependencies allow), and audio (metadata; transcription requires network access).

### Installing the skill

**Claude.ai / Claude Desktop:** Settings → Capabilities → Skills → upload the packaged `.skill` file from this repo's `dist/` folder (or from Releases).

**Claude Code:** copy the skill folder into your skills directory:

```bash
cp -r skills/markitdown-converter ~/.claude/skills/
```

### Using the script directly (no Claude required)

The bundled converter is a standalone Python CLI:

```bash
pip install 'markitdown[all]'

# Single file
python skills/markitdown-converter/scripts/convert.py report.pdf -o report.md

# Folder or ZIP -> one combined markdown file
python skills/markitdown-converter/scripts/convert.py docs.zip -o combined.md

# One .md per input file
python skills/markitdown-converter/scripts/convert.py a.docx b.xlsx --separate -o out/
```

Per-file failures in a batch are reported on stderr and don't abort the rest of the conversion.

### Known limits

- Scanned/image-only PDFs may produce empty text (no OCR layer).
- Audio transcription and YouTube URL conversion require open network access.
- Legacy binary formats (`.doc`, `.ppt`) are unreliable — re-save as the modern format.

---

## Credits & attribution

- **Created by [Rinu](https://github.com/)** in collaboration with **Claude (Anthropic)**, using the `skill-creator` skill with iterative testing against sample documents.
- **[MarkItDown](https://github.com/microsoft/markitdown)** by **Microsoft** — the conversion engine this skill is built on (MIT License). All conversion capability credit goes to the MarkItDown authors and contributors.
- **[Agent Skills](https://docs.claude.com)** format by **Anthropic** — see also Anthropic's public [skills repository](https://github.com/anthropics/skills) for the format and examples.

## License

MIT — see [LICENSE](LICENSE). MarkItDown is a separate project distributed under its own MIT license by Microsoft.

## Contributing

Issues and pull requests welcome. If a file type converts badly, please attach a minimal sample file and the output you got.
